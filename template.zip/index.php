<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	 <meta charset="utf-8">
    <title>home</title>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
	<div>
	
		<div style="background-color: rgb(106, 117, 117); height: 50px">
		    <div class="social">
           <a href=""><span class="fab fa-facebook-f"></span></a>
              <a href="#"><span class="fab fa-twitter"></span></a>
              <a href=""><span class="fab fa-instagram"></span></a>
              <a href=""><span class="fab fa-youtube"></span></a>
                <p>+8801989419776</p>
                <p><a href="">zns601@gmail.com</a></p>
            </div>
        </div>
        <div style="background-color: rgb(35, 60, 204); ">
        	<nav>
        	<ul style="line-height: 40px;">
        		<li class="menu"><a>Home</a>
                    <ul class="sub-menu">
                    	<li><a href="">home2</a></li>
                    	<li><a href="">home3</a></li>
                    </ul>
        		</li>
        		<li class="menu"><a >pages</a>
                       <ul class="sub-menu">
                    	<li><a href="">pages2</a></li>
                    	<li><a href="">pages3</a></li>
                    </ul>
        		</li>
                <li class="menu"><a >Features</a>
                       <ul class="sub-menu">
                    	<li><a href="">features2</a></li>
                    	<li><a href="">features3</a></li>
                    </ul>
                </li>
                <li class="menu"><a >Project</a>

                        <ul class="sub-menu">
                    	<li><a href="">project2</a></li>
                    	<li><a href="">project3</a></li>
                    </ul>
                </li>
                <li class="menu"><a>Blog</a>
                        <ul class="sub-menu">
                    	<li><a href="">blog2</a></li>
                    	<li><a href="">blog3</a></li>
                    </ul>
                </li>
                <li><a href="">Contact Us</a></li>
                <li><form><input type="text" name="search" placeholder="search">
                	<button><i class="fa fa-search" aria-hidden="true"></i></button></form></li>
        	</ul>

        	</nav>
        </div>
        <div class="t">
        	<span><img src="n.jpg" height="400px" width="100%"></span>
        </div>

        <div>
        	<div style="width:70%; left: 15%;height: 250px;background-color: white;position: absolute; ">
        	<div style="width:35%; left:0px; height: 250px ;background-color: white; position: absolute; border: 2px solid black"><div><img src="img/cont.PNG"></div><div><h1>Contact With us</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	<div style="width:35%;height: 250px ;background-color: blue; left:35%; position: absolute;border: 2px solid black "><div><img src="img/pro.PNG"></div><div><h1>Discuss your Problem</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	<div style="width:30%;height: 250px ;background-color: rgb(99, 107, 143); right:0px; position: absolute;border: 2px solid black "><div><img src="img/tre.PNG"></div><div><h1>Get our Solution</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        </div>
    </div>

    <div>
    	 <div style="width:70%;top:800px; left: 15%;height: 350px;background-color: white;position: absolute;">
    	<div style="width:50%; left:0px; height: 350px ;background-color: white; position: absolute; border: 2px solid black">
    		
          <div><h1>15 years experience</h1></div>
          <div><h1>Advance through the modern business system</h1></div>
            <div><img src="img/85.PNG">
            <img src="img/500.PNG">
            <img src="img/4000.PNG">
            </div>


    	</div>
    	<div style="width:50%;height: 350px ; right:0px; position: absolute;border: 2px solid black ">
    		
    		<img src="img/vdo.PNG" height="350px" width="100%">
    	</div>
    	</div>
    </div>

           <div>
        	<div style="width:70%; top:1170px; left: 15%;height: 650px;background-color: rgb(155, 158, 171);position: absolute; ">

              <div style="left: 40%;top:10px;height: 50px;background-color:rgb(155, 158, 171);position: absolute; ">
              	<div><h1 style="line-height:20px">Our Services</h1></div>
              </div>

        		<div style="width:60%; top:70px;left: 15%;height: 250px;background-color: white;position: absolute; ">

        	<div style="width:35%; left:0px; height: 250px ;background-color: white; position: absolute; border: 2px solid black"><div> <img src="img/finan.PNG"></div><div><h1>financial planning</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	
        	<div style="width:35%;height: 250px ;background-color: blue; left:35%; position: absolute;border: 2px solid black "><div> <img src="img/reserach.PNG"></div><div><h1>software research</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	
        	<div style="width:30%;height: 250px ;background-color: rgb(99, 107, 143); right:0px; position: absolute;border: 2px solid black "><div> <img src="img/sol.PNG"></div><div><h1>business services</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	</div>
        

        	<div style="width:60%;top:330px;left: 15%;height: 250px;background-color: white;position: absolute; ">

        	<div style="width:35%; left:0px; height: 250px ;background-color: white; position: absolute; border: 2px solid black"><div> <img src="img/planning.PNG"></div><div><h1>financial planning</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	
        	<div style="width:35%;height: 250px ;background-color: blue; left:35%; position: absolute;border: 2px solid black "><div> <img src="img/ideas.PNG"></div><div><h1>software research</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	
        	<div style="width:30%;height: 250px ;background-color: rgb(99, 107, 143); right:0px; position: absolute;border: 2px solid black "><div> <img src="img/management.PNG"></div><div><h1>business services</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        </div>
    </div>
    </div>

   




    <div>
    	<div style="width:80%; top:1830px; left: 8%;height: 250px;background-color: white;position: absolute; ">
    		<div >
    		<img src="img/worldwide.PNG" width="100%" height="250px">
    	   </div>
    	</div>
    </div>



<div>
        	<div style="width:70%; top:2100px; left: 15%;height: 400px;background-color: rgb(155, 158, 171);position: absolute; ">

            <div style="left: 40%;top:10px;height: 50px;background-color:rgb(155, 158, 171);position: absolute; ">
              	<div><h1 style="line-height:20px">Recent Projects</h1></div>
              </div>

        		<div style="width:60%; top:70px;left: 15%;height: 250px;background-color: white;position: absolute; ">

        	<div style="width:35%; left:0px; height: 250px ;background-color: white; position: absolute; border: 2px solid black"><div><img src="img/double_finan.PNG"></div><div><p>Double Financial profit</p></div></div>
        	<div style="width:34%;height: 250px ;background-color: blue; left:35%; position: absolute;border: 2px solid black "><div><img src="img/bank_invest.PNG"></div><div><p>bank investment idea</p></div></div>
        	<div style="width:31%;height: 250px ;background-color: rgb(99, 107, 143); left:70%; position: absolute;border: 2px solid black "><div><img src="img/bank.PNG"></div><div><p>bank investment plan</p></div></div>
        </div>
    </div>
    </div>


       <div>
    	 <div style="width:70%;top:2520px; left: 15%;height: 250px;background-color: white;position: absolute;">

    	 	<div style="width:50%;height: 250px ; left:0px; position: absolute;border: 2px solid black ">
    		
    		<img src="img/advance.PNG" height="250px" width="100%">
    	</div>

    	<div style="width:50%; right:0px; height: 250px ;background-color: white; position: absolute; border: 2px solid black">
    		
          <div><h1>15 years experience</h1></div>
          <div><h1>Advance through the modern business system</h1></div>
            <div><a href="">contact us</a><br><a href="">learn more</a></div>


    	</div>
    	</div>
    </div>



            <div>
        	<div style="width:70%;top:2790px; left: 15%;height: 150px;background-color: white;position: absolute; ">
        	<div style="width:25%; left:0px; height: 150px ;background-color: white; position: absolute; "><div>	<img src="img/24.PNG"></div><div><h1>24/7 support</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	<div style="width:25%;height: 150px ;background-color: white; left:25%; position: absolute; "><div>	<img src="img/expert.PNG"></div><div><h1>Expert Analysis</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	<div style="width:20%;height: 150px ;background-color: white; left:50%; position: absolute; "><div>	<img src="img/react.PNG"></div><div><h1>100% satisfaction</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        	<div style="width:20%;height: 150px ;background-color: white; left:75%; position: absolute;"><div>	<img src="img/star.PNG"></div><div><h1>Certified company</h1></div><div><p>Like paper money and gold before it bitcoin</p></div></div>
        </div>
    </div>



       <div>
        	<div style="width:70%; top:3000px; left: 15%;height: 550px;background-color: rgb(155, 158, 171);position: absolute; ">

              <div style="left: 40%;top:10px;height: 50px;background-color:rgb(155, 158, 171);position: absolute; ">
              	<div><h1 style="line-height:20px">Latest News</h1></div>
              </div>

        		<div style="width:80%; top:70px;left: 15%;height: 450px;background-color: white;position: absolute; ">

        	<div style="width:35%; left:0px; height: 450px ;background-color: white; position: absolute; border: 2px solid black"><div><h1>Duis autem vel iriure dolor in hendrerit business</h1></div><div><p>Like paper money and gold before it bitcoin</p></div>
               <div><img src="img/duies.PNG"></div>
        </div>
        	<div style="width:35%;height: 450px ;background-color: white; left:35%; position: absolute;border: 2px solid black "><div><h1>Mega Business shutting down due to business fail</h1></div><div><p>Like paper money and gold before it bitcoin</p></div><div><img src="img/mega.PNG"></div></div>
        	<div style="width:30%;height: 450px ;background-color: white; right:0px; position: absolute;border: 2px solid black "><div><h1>investigation demons traverunt business</h1></div><div><p>Like paper money and gold before it bitcoin </p></div><div><img src="img/investment.PNG"></div></div>
        </div>

    </div>
    </div>
    
   
        	<div style="width:100%; top:3590px;height: 250px;background-color: rgb(155, 158, 171);position: absolute; ">
    
    <?php  include("footer.php") ?>
    </div>

</div>
</div>
	
</body>
</html>